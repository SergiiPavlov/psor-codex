import {locales, defaultLocale} from '../i18n';

export default {
  locales: Array.from(locales),
  defaultLocale
};
